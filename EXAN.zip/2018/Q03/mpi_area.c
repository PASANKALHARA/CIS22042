#include <mpi.h>
#include <stdio.h>

int main(int argc, char *argv[]) {
    int rank, size;
    double d1, d2, area;

    // Initialize MPI
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    if (size < 3) {
        if (rank == 0) {
            printf("This program requires at least 3 processes.\n");
        }
        MPI_Finalize();
        return 0;
    }

    if (rank == 0) {
        // Process 0: Get input from user
        printf("Enter the length of diagonal 1: ");
        scanf("%lf", &d1);
        printf("Enter the length of diagonal 2: ");
        scanf("%lf", &d2);

        // Send the input to process 1
        MPI_Send(&d1, 1, MPI_DOUBLE, 1, 0, MPI_COMM_WORLD);
        MPI_Send(&d2, 1, MPI_DOUBLE, 1, 0, MPI_COMM_WORLD);
    } else if (rank == 1) {
        // Process 1: Receive input and calculate area
        MPI_Recv(&d1, 1, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        MPI_Recv(&d2, 1, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

        // Calculate area
        area = 0.5 * d1 * d2;

        // Send the result to process 2
        MPI_Send(&area, 1, MPI_DOUBLE, 2, 0, MPI_COMM_WORLD);
    } else if (rank == 2) {
        // Process 2: Receive the result and display it
        MPI_Recv(&area, 1, MPI_DOUBLE, 1, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        printf("The area of the diamond is: %.2lf\n", area);
    }

    // Finalize MPI
    MPI_Finalize();
    return 0;
}
