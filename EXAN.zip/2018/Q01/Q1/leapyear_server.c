#include "leapyear.h"

bool_t *is_leap_year_1_svc(int *argp, struct svc_req *rqstp) {
    static bool_t result;

    // Determine if the year is a leap year
    if ((*argp % 4 == 0 && *argp % 100 != 0) || (*argp % 400 == 0)) {
        result = TRUE;
    } else {
        result = FALSE;
    }

    return &result;
}
