#include <stdio.h>
#include "vowel.h"

void vowel_prog_1(char *host) {
    CLIENT *clnt;
    bool_t *result_1;
    char is_vowel_1_arg;

#ifndef DEBUG
    clnt = clnt_create(host, VOWEL_PROG, VOWEL_VERS, "udp");
    if (clnt == NULL) {
        clnt_pcreateerror(host);
        exit(1);
    }
#endif /* DEBUG */

    // Continuous input loop
    while (1) {
        printf("Enter a character (or '0' to exit): ");
        scanf(" %c", &is_vowel_1_arg);

        if (is_vowel_1_arg == '0') {
            printf("Exiting...\n");
            break;
        }

        result_1 = is_vowel_1(&is_vowel_1_arg, clnt);
        if (result_1 == (bool_t *)NULL) {
            clnt_perror(clnt, "call failed");
            continue;
        }

        // Display the result
        if (*result_1) {
            printf("'%c' is a vowel.\n", is_vowel_1_arg);
        } else {
            printf("'%c' is not a vowel.\n", is_vowel_1_arg);
        }
    }

#ifndef DEBUG
    clnt_destroy(clnt);
#endif /* DEBUG */
}

int main(int argc, char *argv[]) {
    char *host;

    if (argc < 2) {
        printf("usage: %s server_host\n", argv[0]);
        exit(1);
    }
    host = argv[1];
    vowel_prog_1(host);
    exit(0);
}
