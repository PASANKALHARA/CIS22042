#include "vowel.h"

bool_t *is_vowel_1_svc(char *argp, struct svc_req *rqstp) {
    static bool_t result;

    // Check if the character is a vowel
    char ch = *argp;
    if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u' ||
        ch == 'A' || ch == 'E' || ch == 'I' || ch == 'O' || ch == 'U') {
        result = TRUE;
    } else {
        result = FALSE;
    }

    return &result;
}
