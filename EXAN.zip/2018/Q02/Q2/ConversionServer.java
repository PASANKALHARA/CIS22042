import java.rmi.*;
import java.rmi.registry.*;

public class ConversionServer {
    public static void main(String[] args) {
        try {
            // Start the RMI registry
            System.out.println("RMI Registry started.");

            // Create and bind the remote object
            ConversionService service = new ConversionServiceImpl();
            Naming.rebind("ConversionService", service);
            System.out.println("ConversionService is ready.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
