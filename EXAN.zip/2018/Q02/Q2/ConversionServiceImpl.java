import java.rmi.*;
import java.rmi.server.*;

public class ConversionServiceImpl extends UnicastRemoteObject implements ConversionService {
    protected ConversionServiceImpl() throws RemoteException {
        super();
    }

    @Override
    public String decimalToOctal(int decimal) throws RemoteException {
        StringBuilder octal = new StringBuilder();
        while (decimal > 0) {
            int remainder = decimal % 8;
            octal.insert(0, remainder); // Append remainder at the beginning
            decimal /= 8;
        }
        return octal.toString();
    }
}
