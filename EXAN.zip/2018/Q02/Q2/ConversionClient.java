import java.rmi.*;
import java.util.Scanner;

public class ConversionClient {
    public static void main(String[] args) {
        try {
            // Look up the remote object
            ConversionService service = (ConversionService) Naming.lookup("ConversionService");

            // Take user input
            Scanner scanner = new Scanner(System.in);
            System.out.print("Enter a decimal number: ");
            int decimal = scanner.nextInt();

            // Call the remote method and display the result
            String octal = service.decimalToOctal(decimal);
            System.out.println("The octal representation of " + decimal + " is: " + octal);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
