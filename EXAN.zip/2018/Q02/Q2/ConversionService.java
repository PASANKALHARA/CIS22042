import java.rmi.*;


public interface ConversionService extends Remote {
    String decimalToOctal(int decimal) throws RemoteException;
}
