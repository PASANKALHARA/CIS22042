import java.rmi.*;
import java.rmi.registry.*;

public class SumServer {
    public static void main(String[] args) {
        try {
            // Start RMI Registry
            System.out.println("RMI Registry started.");

            // Bind the remote object
            SumService service = new SumServiceImpl();
            Naming.rebind("SumService", service);
            System.out.println("SumService is bound and ready for use.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
