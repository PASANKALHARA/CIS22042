import java.rmi.*;
import java.util.Scanner;

public class SumClient {
    public static void main(String[] args) {
        try {
            // Look up the remote object
            SumService service = (SumService) Naming.lookup("SumService");

            // Get range from user
            Scanner scanner = new Scanner(System.in);
            System.out.print("Enter the start of the range: ");
            int start = scanner.nextInt();
            System.out.print("Enter the end of the range: ");
            int end = scanner.nextInt();

            // Call the remote method
            int result = service.calculateSum(start, end);
            System.out.println("The sum of natural numbers from " + start + " to " + end + " is: " + result);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
