import java.rmi.*;

public interface SumService extends Remote {
    int calculateSum(int start, int end) throws RemoteException;
}
