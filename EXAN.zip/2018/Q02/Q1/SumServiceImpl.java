import java.rmi.*;
import java.rmi.server.*;

public class SumServiceImpl extends UnicastRemoteObject implements SumService {
    protected SumServiceImpl() throws RemoteException {
        super();
    }

    @Override
    public int calculateSum(int start, int end) throws RemoteException {
        if (start > end) {
            throw new IllegalArgumentException("Start cannot be greater than end.");
        }
        int sum = 0;
        for (int i = start; i <= end; i++) {
            sum += i;
        }
        return sum;
    }
}
