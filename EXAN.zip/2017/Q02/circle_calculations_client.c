#include "circle_calculations.h"
#include <stdio.h>
#include <stdlib.h>

void circle_prog_1(char *host) {
    CLIENT *clnt;
    CircleResult *result_1;
    CircleInput calculate_circle_1_arg;

    // Get radius from the user
    printf("Enter the radius of the circle: ");
    scanf("%lf", &(calculate_circle_1_arg.radius));

    // Create RPC client
    clnt = clnt_create(host, CIRCLE_PROG, CIRCLE_VERS, "udp");
    if (clnt == NULL) {
        clnt_pcreateerror(host);
        exit(1);
    }

    // Call the remote procedure
    result_1 = calculate_circle_1(&calculate_circle_1_arg, clnt);
    if (result_1 == (CircleResult *)NULL) {
        clnt_perror(clnt, "call failed");
        exit(1);
    }

    // Display the results
    printf("Circumference: %.2lf\n", result_1->circumference);
    printf("Area: %.2lf\n", result_1->area);

    // Clean up
    clnt_destroy(clnt);
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        printf("Usage: %s server_host\n", argv[0]);
        exit(1);
    }
    circle_prog_1(argv[1]);
    return 0;
}
