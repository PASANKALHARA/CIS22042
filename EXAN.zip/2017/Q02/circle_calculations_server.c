#include "circle_calculations.h"
#include <stdio.h>

CircleResult *calculate_circle_1_svc(CircleInput *argp, struct svc_req *rqstp) {
    static CircleResult result;

    double radius = argp->radius;
    double pi = 3.14;

    printf("Server received radius: %.2lf\n", radius); // Debugging log
    result.circumference = 2 * pi * radius;
    result.area = pi * radius * radius;

    printf("Server calculated circumference: %.2lf\n", result.circumference); // Debugging log
    printf("Server calculated area: %.2lf\n", result.area); // Debugging log

    return &result;
}
