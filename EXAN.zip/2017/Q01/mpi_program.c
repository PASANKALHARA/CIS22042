#include <mpi.h>
#include <stdio.h>

int main(int argc, char** argv) {
    MPI_Init(NULL, NULL);

    int world_size;
    MPI_Comm_size(MPI_COMM_WORLD, &world_size);

    int world_rank;
    MPI_Comm_rank(MPI_COMM_WORLD, &world_rank);

    // Part a: Print the message "CIS 22042 - Practical Examination" with 3 processes
    if (world_size == 3) {
        printf("Process %d out of %d: CIS 22042 - Practical Examination\n", world_rank, world_size);
    }

    // Part b: Send and receive number 50 (an integer value) from process 0 with 2 processes
    if (world_size == 2) {
        int number = 50;
        if (world_rank == 0) {
            MPI_Send(&number, 1, MPI_INT, 1, 0, MPI_COMM_WORLD);
            printf("Process 0 sent number %d to Process 1\n", number);
        } else if (world_rank == 1) {
            MPI_Recv(&number, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            printf("Process 1 received number %d from Process 0\n", number);
        }
    }

    // Part c: Calculate the time of an MPI communication with 4 processes
    if (world_size == 4) {
        double start_time, end_time;

        if (world_rank == 0) {
            int data = 123;
            start_time = MPI_Wtime();
            MPI_Send(&data, 1, MPI_INT, 1, 0, MPI_COMM_WORLD);
            MPI_Recv(&data, 1, MPI_INT, 1, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            end_time = MPI_Wtime();
            printf("Time for communication: %f seconds\n", end_time - start_time);
        } else if (world_rank == 1) {
            int data;
            MPI_Recv(&data, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            MPI_Send(&data, 1, MPI_INT, 0, 0, MPI_COMM_WORLD);
        }
    }

    MPI_Finalize();
    return 0;
}
