import java.rmi.server.*;
import java.rmi.*;

public class SquareCalculatorImpl extends UnicastRemoteObject implements SquareCalculator {

    // Constructor
    public SquareCalculatorImpl() throws RemoteException {
        super();
    }

    // Implement the remote method
    @Override
    public int getSquare(int number) throws RemoteException {
        return number * number;
    }
}
