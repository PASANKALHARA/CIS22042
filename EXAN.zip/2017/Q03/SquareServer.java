import java.rmi.*;
public class SquareServer {
    public static void main(String[] args) {
        try {
            // Create an instance of the implementation class
            SquareCalculatorImpl calculator = new SquareCalculatorImpl();
            Naming.rebind("SquareService", calculator);

            System.out.println("Square Server is ready.");
        } catch (Exception e) {
            System.err.println("Server exception: " + e.toString());
            e.printStackTrace();
        }
    }
}
