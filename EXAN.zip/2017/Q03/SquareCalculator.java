import java.rmi.*;

public interface SquareCalculator extends Remote {
    // Method to calculate the square of a number
    int getSquare(int number) throws RemoteException;
}
