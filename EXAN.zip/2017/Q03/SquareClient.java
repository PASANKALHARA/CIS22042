import java.rmi.*;

public class SquareClient {
    public static void main(String[] args) {
        try {

            // Look up the remote object
            SquareCalculator calculator = (SquareCalculator) Naming.lookup("SquareService");

            // Invoke the remote method
            int number = 5; // Example input
            int square = calculator.getSquare(number);
            System.out.println("Square of " + number + " is " + square);
        } catch (Exception e) {
            System.err.println("Client exception: " + e.toString());
            e.printStackTrace();
        }
    }
}
