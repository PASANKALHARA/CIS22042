#include "reverse_number.h"

int *reverse_number_1_svc(int *argp, struct svc_req *rqstp) {
    static int result;
    int num = *argp;
    result = 0;

    while (num != 0) {
        result = result * 10 + num % 10;
        num /= 10;
    }

    return &result;
}
