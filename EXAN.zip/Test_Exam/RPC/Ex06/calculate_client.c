#include "calculate.h"
#include <stdio.h>
#include <stdlib.h>

// Global variables
double width, length, base, height, a, b, c, r1, r2;

void claculater_1(char *host) {
    CLIENT *clnt;
    double *result_1;
    area areamethod_1_arg;
    double *result_2;
    perieter perietermthod_1_arg;

    // Initialize struct values
    areamethod_1_arg.width = width;
    areamethod_1_arg.height = height;

    perietermthod_1_arg.width = width;
    perietermthod_1_arg.length = length;

#ifndef DEBUG
    clnt = clnt_create(host, CLACULATER, RECTANGAL, "udp");
    if (clnt == NULL) {
        clnt_pcreateerror(host);
        exit(1);
    }
#endif

    result_1 = areamethod_1(&areamethod_1_arg, clnt);
    if (result_1 == NULL) {
        clnt_perror(clnt, "call failed");
    } else {
        r1 = *result_1;
    }

    result_2 = perietermthod_1(&perietermthod_1_arg, clnt);
    if (result_2 == NULL) {
        clnt_perror(clnt, "call failed");
    } else {
        r2 = *result_2;
    }

#ifndef DEBUG
    clnt_destroy(clnt);
#endif
}

void claculater_2(char *host) {
    CLIENT *clnt;
    double *result_1;
    area areamethod_2_arg;
    double *result_2;
    perieter perietermthod_2_arg;

    // Initialize struct values
    areamethod_2_arg.base = base;
    areamethod_2_arg.height = height;

    perietermthod_2_arg.a = a;
    perietermthod_2_arg.b = b;
    perietermthod_2_arg.c = c;

#ifndef DEBUG
    clnt = clnt_create(host, CLACULATER, TRIANGLE, "udp");
    if (clnt == NULL) {
        clnt_pcreateerror(host);
        exit(1);
    }
#endif

    result_1 = areamethod_2(&areamethod_2_arg, clnt);
    if (result_1 == NULL) {
        clnt_perror(clnt, "call failed");
    } else {
        r1 = *result_1;
    }

    result_2 = perietermthod_2(&perietermthod_2_arg, clnt);
    if (result_2 == NULL) {
        clnt_perror(clnt, "call failed");
    } else {
        r2 = *result_2;
    }

#ifndef DEBUG
    clnt_destroy(clnt);
#endif
}

int main(int argc, char *argv[]) {
    char *host;

    if (argc < 2) {
        printf("Usage: %s server_host\n", argv[0]);
        exit(1);
    }
    host = argv[1];

    while (1) {
        int choice;
        printf("\nMenu:\n");
        printf("1. Rectangle Area Calculate\n");
        printf("2. Rectangle Perimeter Calculate\n");
        printf("3. Triangle Area Calculate\n");
        printf("4. Triangle Perimeter Calculate\n");
        printf("5. Exit\n");
        printf("Enter Your Selection: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter width: ");
                scanf("%lf", &width);
                printf("Enter height: ");
                scanf("%lf", &height);
                claculater_1(host);
                printf("Area of rectangle: %lf\n", r1);
                break;

            case 2:
                printf("Enter width: ");
                scanf("%lf", &width);
                printf("Enter length: ");
                scanf("%lf", &length);
                claculater_1(host);
                printf("Perimeter of rectangle: %lf\n", r2);
                break;

            case 3:
                printf("Enter base: ");
                scanf("%lf", &base);
                printf("Enter height: ");
                scanf("%lf", &height);
                claculater_2(host);
                printf("Area of triangle: %lf\n", r1);
                break;

            case 4:
                printf("Enter side a: ");
                scanf("%lf", &a);
                printf("Enter side b: ");
                scanf("%lf", &b);
                printf("Enter side c: ");
                scanf("%lf", &c);
                claculater_2(host);
                printf("Perimeter of triangle: %lf\n", r2);
                break;

            case 5:
                printf("Exiting program.\n");
                exit(0);

            default:
                printf("Invalid choice. Please try again.\n");
        }
    }

    return 0;
}
