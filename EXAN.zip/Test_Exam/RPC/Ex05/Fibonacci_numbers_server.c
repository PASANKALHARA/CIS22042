#include "Fibonacci_numbers.h"

int fibonacci_recursive(int n) {
    if (n <= 0) {
        return -1; // Return -1 for invalid input
    } else if (n == 1) {
        return 0;
    } else if (n == 2) {
        return 1;
    } else {
        return fibonacci_recursive(n - 1) + fibonacci_recursive(n - 2);
    }
}

int *
fiboniacci_rpc_1_svc(num *argp, struct svc_req *rqstp)
{
	static int  result;

	int number =argp->number;
	int fibonacci_number;
	
	fibonacci_number= fibonacci_recursive(number);

	result =fibonacci_number;

	return &result;
}
