#include "string_analysis.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void string_analysis_pro_1(char *host) {
    CLIENT *clnt;
    vowel_consonant_result *result;
    vowels analyze_string_1_arg;

    clnt = clnt_create(host, STRING_ANALYSIS_PRO, STRING_ANALYSIS_VER, "udp");
    if (clnt == NULL) {
        clnt_pcreateerror(host);
        exit(1);
    }

    printf("Enter a string: ");
    fgets(analyze_string_1_arg.word, sizeof(analyze_string_1_arg.word), stdin);
    analyze_string_1_arg.word[strcspn(analyze_string_1_arg.word, "\n")] = '\0'; // Remove newline

    result = analyze_string_1(&analyze_string_1_arg, clnt);
    if (result == NULL) {
        clnt_perror(clnt, "call failed");
    } else {
        printf("Vowels: %d, Consonants: %d\n", result->vowels, result->consonants);
    }

    clnt_destroy(clnt);
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        printf("usage: %s server_host\n", argv[0]);
        exit(1);
    }
    string_analysis_pro_1(argv[1]);
    return 0;
}
