#include "string_analysis.h"
#include <ctype.h>
#include <string.h>

vowel_consonant_result *analyze_string_1_svc(vowels *argp, struct svc_req *rqstp) {
    static vowel_consonant_result result;
    const char *input = argp->word;
    result.vowels = 0;
    result.consonants = 0;

    for (int i = 0; input[i] != '\0'; ++i) {
        char ch = tolower(input[i]);
        if (isalpha(ch)) {
            if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u') {
                result.vowels++;
            } else {
                result.consonants++;
            }
        }
    }
    return &result;
}
