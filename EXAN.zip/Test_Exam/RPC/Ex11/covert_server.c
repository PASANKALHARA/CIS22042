#include "covert.h"

char **
word_1_svc(value *argp, struct svc_req *rqstp)
{
	static char * result;

	 int choose=argp->number;

	 switch (choose) {
  			case 1:
  				result="One";
    			break;
  			case 2:
   				result="two";
    			break;
    		case 3:
   				result="Three";
    			break;
    		case 4:
  				result="Four";
    			break;
  			case 5:
   				result="five";
    			break;
    		case 6:
   				result="Six";
    			break;
    		case 7:
   				result="Seven";
    			break;
    		case 8:
  				result="Eight";
    			break;
  			case 9:
   				result="Nine";
    			break;
    		case 0:
   				result="Zwro";
    			break;

  			default:
  				result="Invalid Input";
  				break;
		}

	return &result;
}
