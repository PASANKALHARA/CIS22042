#include "circle.h"


void
circle_1(char *host)
{
	CLIENT *clnt;
	double  *result_1;
	Input  calculate_circumference_1_arg;
	double  *result_2;
	Input  calculate_area_1_arg;
	double redius ;

#ifndef	DEBUG
	clnt = clnt_create (host, CIRCLE, CIRCLEVAR, "udp");
	if (clnt == NULL) {
		clnt_pcreateerror (host);
		exit (1);
	}
#endif	/* DEBUG */
	printf("Enter the redius of the circle : ");
	scanf("%lf",&redius);
	calculate_circumference_1_arg.radius=redius;
	calculate_area_1_arg.radius=redius;

	result_1 = calculate_circumference_1(&calculate_circumference_1_arg, clnt);
	if (result_1 == (double *) NULL) {
		clnt_perror (clnt, "call failed");
	}else{
		printf("Circle circumference is : %lf\n",*result_1);
	}
	result_2 = calculate_area_1(&calculate_area_1_arg, clnt);
	if (result_2 == (double *) NULL) {
		clnt_perror (clnt, "call failed");
	}else{
		printf("Circle area is : %lf\n",*result_2);
	}

#ifndef	DEBUG
	clnt_destroy (clnt);
#endif	 /* DEBUG */
}


int
main (int argc, char *argv[])
{
	char *host;

	if (argc < 2) {
		printf ("usage: %s server_host\n", argv[0]);
		exit (1);
	}
	host = argv[1];
	circle_1 (host);
exit (0);
}
