#include "circle.h"
double pi =3.14;
double radius;

double *
calculate_circumference_1_svc(Input *argp, struct svc_req *rqstp)
{
	static double  result;

	radius = argp->radius;

	result =2*pi*radius ;

	return &result;
}

double *
calculate_area_1_svc(Input *argp, struct svc_req *rqstp)
{
	static double  result;


	radius = argp->radius;
	result =2*pi*radius*radius ;


	return &result;
}
