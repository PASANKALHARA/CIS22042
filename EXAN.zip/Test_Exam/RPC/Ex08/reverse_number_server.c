

#include "reverse_number.h"

int *
reverse_number_1_svc(num *argp, struct svc_req *rqstp)
{
	static int  result;

	int num = argp->num;
    result = 0;

    while (num != 0) {
        result = result * 10 + num % 10;
        num /= 10;
    }

	return &result;
}
