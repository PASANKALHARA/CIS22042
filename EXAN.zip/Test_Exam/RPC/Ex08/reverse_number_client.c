#include "reverse_number.h"

void
reverse_number_prog_1(char *host)
{
	CLIENT *clnt;
	int  *result_1;
	num  reverse_number_1_arg;

#ifndef	DEBUG
	clnt = clnt_create (host, REVERSE_NUMBER_PROG, REVERSE_NUMBER_VERS, "udp");
	if (clnt == NULL) {
		clnt_pcreateerror (host);
		exit (1);
	}
#endif	/* DEBUG */

	printf("Enter a number to reverse: ");
    scanf("%d", &(reverse_number_1_arg));

	result_1 = reverse_number_1(&reverse_number_1_arg, clnt);
	if (result_1 == (int *) NULL) {
		clnt_perror (clnt, "call failed");
	}else{
		printf("Reversed number: %d\n", *result_1);
	}
#ifndef	DEBUG
	clnt_destroy (clnt);
#endif	 /* DEBUG */
}


int
main (int argc, char *argv[])
{
	char *host;

	if (argc < 2) {
		printf ("usage: %s server_host\n", argv[0]);
		exit (1);
	}
	host = argv[1];
	reverse_number_prog_1 (host);
exit (0);
}
