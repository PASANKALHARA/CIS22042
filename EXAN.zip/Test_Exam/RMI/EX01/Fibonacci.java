import java.rmi.*;

public interface Fibonacci extends Remote {
    String getFibonacciSeries(int n) throws RemoteException;
}
