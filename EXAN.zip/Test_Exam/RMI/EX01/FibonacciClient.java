import java.rmi.*;

public class FibonacciClient {
    public static void main(String[] args) {
        if (args.length != 1) {
            System.out.println("Usage: java FibonacciClient <number>");
            return;
        }
        try {
            int n = Integer.parseInt(args[0]);
            Fibonacci fib = (Fibonacci) Naming.lookup("FibonacciService");
            String result = fib.getFibonacciSeries(n);
            System.out.println("Fibonacci Series: " + result);
        } catch (Exception e) {
            System.err.println("Client exception: " + e.toString());
            e.printStackTrace();
        }
    }
}
