import java.rmi.*;

public class FibonacciServer {
    public static void main(String[] args) {
        try {
            FibonacciImpl fib = new FibonacciImpl();
            Naming.rebind("FibonacciService", fib);
            System.out.println("Fibonacci Service is running...");
        } catch (Exception e) {
            System.err.println("Server exception: " + e.toString());
            e.printStackTrace();
        }
    }
}
