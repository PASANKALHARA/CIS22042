import java.rmi.*;
import java.math.BigInteger;

public interface Factorial extends Remote {
    
    BigInteger calculateFactorial(int n) throws RemoteException;
}
