import java.rmi.*;
import java.rmi.registry.*;

public class FactorialServer {
    public static void main(String[] args) {
        try {
           
            Factorial factorialService = new FactorialImpl();


            // Bind the remote object (stub) in the registry
            Naming.rebind("FactorialService", factorialService);

            System.out.println("Server is running...");
        } catch (Exception e) {
            System.out.println("Server Error: " + e);
        }
    }
}
