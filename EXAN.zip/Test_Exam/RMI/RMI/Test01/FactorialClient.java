import java.rmi.*;
import java.math.BigInteger;
import java.util.Scanner;

public class FactorialClient {
    public static void main(String[] args) {
        try {
          
            Factorial service = (Factorial) Naming.lookup("FactorialService");

            Scanner scanner = new Scanner(System.in);
            System.out.print("Enter a number to calculate factorial: ");
            int number = scanner.nextInt();

           
            BigInteger result = service.calculateFactorial(number);

          
            System.out.println("Factorial of " + number + " is: " + result);
        } catch (Exception e) {
            System.out.println("Client Error: " + e);
        }
    }
}
