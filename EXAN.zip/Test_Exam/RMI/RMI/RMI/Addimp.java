import java.rmi.*;
import java.rmi.server.*;

public class Addimp extends UnicastRemoteObject implements Adder {
	Addimp() throws RemoteException {
		super();
	}

	public  int add(int x,int y){
		return x + y;
	}
}