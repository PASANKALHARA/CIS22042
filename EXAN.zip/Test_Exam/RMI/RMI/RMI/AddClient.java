import java.rmi.*;

public class AddClient{
	public static void main(String[]args){

		try{
			Adder a1 = (Adder) Naming.lookup("ABC");

			System.out.println("sum :"+ a1.add(4,5));
		}

		catch(Exception e){
			System.out.println("Error:"+ e);
		}
	}
}