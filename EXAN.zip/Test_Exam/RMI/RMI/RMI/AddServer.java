import java.rmi.*;
import java.rmi.registry.*;

public class AddServer {
	
	public static void main(String[]args){

		try{

			Adder a = new Addimp();

			Naming.rebind("ABC",a);

			System.out.println("sever is connected");

		}
		catch(Exception e){
			System.out.println("Error :" + e);

		}
	}
}