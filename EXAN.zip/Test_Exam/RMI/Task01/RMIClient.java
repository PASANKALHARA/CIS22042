import java.rmi.*;

public class RMIClient {
    public static void main(String[] args) {
        try {
          
            StudentMarks studentMarks = (StudentMarks) Naming.lookup("ABC");
            int mark1 = 85;
            int mark2 = 90;
            int mark3 = 75;     
            float average = studentMarks.calculateAverage(mark1, mark2, mark3);
            System.out.println("The average mark is: " + average);
        } catch (Exception e) {
            System.out.println("Client exception: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
