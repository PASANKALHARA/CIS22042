import java.rmi.*;
import java.rmi.*;

public interface StudentMarks extends Remote {
    
    public float calculateAverage(int mark1, int mark2, int mark3) throws RemoteException;
}
