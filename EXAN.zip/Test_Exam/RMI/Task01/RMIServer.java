import java.rmi.*;
import java.rmi.registry.*;

public class RMIServer {
    public static void main(String[] args) {
        try {
          
            StudentMarksImpl studentMarks = new StudentMarksImpl();
            
            Naming.rebind("ABC", studentMarks);
            
            System.out.println("Server is ready.");
        } catch (Exception e) {
            System.out.println("Server exception: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
