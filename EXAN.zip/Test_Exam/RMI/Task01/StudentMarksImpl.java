import java.rmi.server.*;
import java.rmi.*;

public class StudentMarksImpl extends UnicastRemoteObject implements StudentMarks {
    
    protected StudentMarksImpl() throws RemoteException {
        super();
    }

    @Override
    public float calculateAverage(int mark1, int mark2, int mark3) throws RemoteException {
        int sum = mark1 + mark2 + mark3;
        return sum / 3.0f;  
    }
}
