import java.rmi.server.*;
import java.rmi.*;
import java.util.HashMap;
import java.util.Map;
public class WeatherServiceImpl extends UnicastRemoteObject implements WeatherService {
    private Map<String, String> weatherData;
    protected WeatherServiceImpl() throws RemoteException {
        super();
        weatherData = new HashMap<>();
        weatherData.put("New York", "Temperature: 22°C, Humidity: 60%, Forecast: Sunny");
        weatherData.put("London", "Temperature: 18°C, Humidity: 75%, Forecast: Cloudy");
        weatherData.put("Tokyo", "Temperature: 28°C, Humidity: 65%, Forecast: Rainy");
        weatherData.put("Mumbai", "Temperature: 32°C, Humidity: 80%, Forecast: Thunderstorms");
        weatherData.put("Paris", "Temperature: 20°C, Humidity: 70%, Forecast: Overcast");
    }
    @Override
    public String getWeatherInfo(String city) throws RemoteException {
        String weatherInfo = weatherData.get(city);
        if (weatherInfo != null) {
            return "Weather Info for " + city + ": " + weatherInfo;
        } else {
            return "Weather information for " + city + " is not available.";
        }
    }
}
