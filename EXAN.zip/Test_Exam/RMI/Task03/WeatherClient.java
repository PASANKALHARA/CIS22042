import java.rmi.*;
import java.util.Scanner;

public class WeatherClient {
    public static void main(String[] args) {
        try {
            WeatherService weatherService = (WeatherService) Naming.lookup("ABC");
            Scanner scanner = new Scanner(System.in);
            System.out.print("Enter the city name to get weather information: ");
            String city = scanner.nextLine();
            String weatherInfo = weatherService.getWeatherInfo(city);
            System.out.println(weatherInfo);
        } catch (Exception e) {
            System.out.println("Client exception: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
