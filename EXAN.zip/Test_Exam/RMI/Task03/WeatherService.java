import java.rmi.*;
public interface WeatherService extends Remote {
    public String getWeatherInfo(String city) throws RemoteException;
}
