import java.rmi.*;
import java.rmi.registry.*;

public class WeatherServer {
    public static void main(String[] args) {
        try {
            
            WeatherServiceImpl weatherService = new WeatherServiceImpl();
            Naming.rebind("ABC", weatherService);
            
            System.out.println("Weather Server is ready.");
        } catch (Exception e) {
            System.out.println("Server exception: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
