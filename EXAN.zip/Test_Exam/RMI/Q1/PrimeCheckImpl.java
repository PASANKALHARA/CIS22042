import java.rmi.*;
import java.rmi.server.*;

public class PrimeCheckImpl extends UnicastRemoteObject implements Prime {
    protected PrimeCheckImpl() throws RemoteException {
        super();
    }
    @Override
    public boolean isPrime(int number) throws RemoteException {
        if (number <= 1) return false; 
        for (int i = 2; i <= Math.sqrt(number); i++) {
            if (number % i == 0) return false; 
        }
        return true; 
    }    
}
