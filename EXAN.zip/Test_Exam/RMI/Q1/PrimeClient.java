import java.rmi.*;

public class PrimeClient {
    public static void main(String[] args) {
        try {
            
            Prime prime = (Prime) Naming.lookup("ABC");
            int numberToCheck = 10; 
            boolean isPrime = prime.isPrime(numberToCheck);
            System.out.println("Is " + numberToCheck + " a prime number? " + isPrime);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
