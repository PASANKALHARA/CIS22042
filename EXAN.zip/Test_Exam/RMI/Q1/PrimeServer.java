import java.rmi.*;
import java.rmi.registry.*;

public class PrimeServer {
    public static void main(String[] args) {
        try { 
            PrimeCheckImpl primeCheck = new PrimeCheckImpl();
            Naming.rebind("ABC", primeCheck);
            System.out.println("RMI Server is running...");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
