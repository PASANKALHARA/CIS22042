import java.rmi.*;

public interface Prime extends Remote {
    
    boolean isPrime(int number) throws RemoteException;
}
