import java.rmi.*;
import java.util.*;

public class StudentClient {
    public static void main(String[] args) {
        try {
            
            Student service = (Student) Naming.lookup("StudentService");
            collectUserDetails();
        } catch (Exception e) {
            System.out.println("Client Error: " + e);
        }
    }
private static void collectUserDetails() {
        Scanner scanner = new Scanner(System.in);
        // Get user's personal information
        System.out.print("Enter your name: ");
        String name = scanner.nextLine();
        System.out.print("Enter your age: ");
        int age = scanner.nextInt();
        System.out.println("Enter your soce: ");
        String cose = scanner.nextLine();  
        System.out.print("Enter your registration number: ");
        String regNumber = scanner.nextLine();
        // Display user inputs
        System.out.println("\nUser Details:");
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("Cose: " + cose);
        System.out.println("Registration Number: " + regNumber);
    }
}
