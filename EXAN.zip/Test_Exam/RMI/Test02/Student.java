import java.rmi.*;


public interface Student extends Remote {
    
}
