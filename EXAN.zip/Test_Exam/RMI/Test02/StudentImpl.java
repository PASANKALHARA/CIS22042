import java.rmi.*;
import java.rmi.server.*;

public class StudentImpl extends UnicastRemoteObject implements Student {

    
    public StudentImpl() throws RemoteException {
        super();
    }
}
