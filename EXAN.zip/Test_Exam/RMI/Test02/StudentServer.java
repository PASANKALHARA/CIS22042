import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;

public class StudentServer {
    public static void main(String[] args) {
        try {
            
            Student studentService = new StudentImpl();
            Naming.rebind("StudentService", studentService);

            System.out.println("Server is running...");
        } catch (Exception e) {
            System.out.println("Server Error: " + e);
        }
    }
}
