import java.rmi.*;
import java.rmi.server.*;

public class FibonacciImpl extends UnicastRemoteObject implements Fibonacci {
    protected FibonacciImpl() throws RemoteException {
        super();
    }
    @Override
    public int[] calculateFibonacci(int number) throws RemoteException {
        if (number < 0) {
            throw new IllegalArgumentException("Number must be non-negative.");
        }
        int[] fibSequence = new int[number + 1];
        if (number >= 0) fibSequence[0] = 0;
        if (number >= 1) fibSequence[1] = 1;
        for (int i = 2; i <= number; i++) {
            fibSequence[i] = fibSequence[i - 1] + fibSequence[i - 2];
        }
        return fibSequence;
    }
}