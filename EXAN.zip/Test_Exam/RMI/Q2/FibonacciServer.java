import java.rmi.*;
import java.rmi.registry.*;

public class FibonacciServer {
    public static void main(String[] args) {
        try {

            FibonacciImpl fibonacci = new FibonacciImpl();
            Naming.rebind("ABC", fibonacci);
            System.out.println("RMI Server is running...");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
