import java.rmi.*;

public interface Fibonacci extends Remote {
    int[] calculateFibonacci(int number) throws RemoteException;
}
