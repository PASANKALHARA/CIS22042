import java.rmi.Naming;

public class FibonacciClient {
    public static void main(String[] args) {
        try {
           
            Fibonacci fibonacci = (Fibonacci) Naming.lookup("ABC");  
            int number = 7; 
            int[] result = fibonacci.calculateFibonacci(number);
            System.out.print("Fibonacci sequence up to F(" + number + "): ");
            for (int i = 0; i <= number; i++) {
                System.out.print(result[i] + " ");
            }
            System.out.println();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
