import java.rmi.*;
import java.rmi.registry.*;

public class SquareServer {
    public static void main(String[] args) {
        try {
            SquareCalculatorImpl squareCalculator = new SquareCalculatorImpl();
            
            Naming.rebind("ABC", squareCalculator);
            
            System.out.println("Server is ready.");
        } catch (Exception e) {
            System.out.println("Server exception: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
