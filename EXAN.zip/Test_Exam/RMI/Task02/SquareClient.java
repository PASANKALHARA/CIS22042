import java.rmi.*;

public class SquareClient {
    public static void main(String[] args) {
        try {
            if (args.length == 0) {
                System.out.println("Please provide a number as a command line argument.");
                return;
            }
            int number = Integer.parseInt(args[0]);
            SquareCalculator squareCalculator = (SquareCalculator) Naming.lookup("ABC");
            int square = squareCalculator.getSquare(number);
            System.out.println("The square of " + number + " is: " + square);
        } catch (Exception e) {
            System.out.println("Client exception: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
