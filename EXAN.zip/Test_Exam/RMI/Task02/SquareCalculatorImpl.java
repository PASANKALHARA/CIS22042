import java.rmi.server.*;
import java.rmi.*;

public class SquareCalculatorImpl extends UnicastRemoteObject implements SquareCalculator {
    
    protected SquareCalculatorImpl() throws RemoteException {
        super();
    }

    @Override
    public int getSquare(int number) throws RemoteException {
        return number * number;  
    }
}