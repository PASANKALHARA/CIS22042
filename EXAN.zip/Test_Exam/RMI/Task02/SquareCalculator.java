import java.rmi.*;


public interface SquareCalculator extends Remote {
   
    public int getSquare(int number) throws RemoteException;
}
