#include <mpi.h>
#include <stdio.h>

int main(int argc, char** argv){

	// intialize 
	MPI_Init(NULL,NULL);

	//no of processes
	int world_size;
	MPI_Comm_size(MPI_COMM_WORLD,&world_size);

	//rank of the process
	int world_rank;
	MPI_Comm_rank(MPI_COMM_WORLD,&world_rank);

	//no of porcesses should be atleast 2
	if(world_size<2){
		printf("No. of processes has to be atleast 2\n");
		MPI_Abort(MPI_COMM_WORLD,1);

	}

	//ping pong logic
	int PING_PONG_LIMIT = 10;
	int ping_pong_count = 0;
	int partner_rank = (world_rank+1)%2;

	while(ping_pong_count< PING_PONG_LIMIT){
		if(world_rank == ping_pong_count%2){
			ping_pong_count++;
			MPI_Send(&ping_pong_count,1,MPI_INT,partner_rank,0,MPI_COMM_WORLD);
		}
		else{
			MPI_Recv(&ping_pong_count,1,MPI_INT,partner_rank,0,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
			printf("Process %d receive count %d from process %d\n",world_rank,ping_pong_count,partner_rank);
	}
	}

	//finalize
	MPI_Finalize();

}