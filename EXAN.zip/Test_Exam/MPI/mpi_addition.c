#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv) {
    int rank, size;
    int num1 = 0, num2 = 0, sum = 0;

    // Initialize MPI environment
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    if (size != 2) {
        if (rank == 0) {
            printf("This program requires exactly 2 processes.\n");
        }
        MPI_Finalize();
        return -1;
    }

    if (rank == 0) {
        // Process 0 assigns the first number
        num1 = 10;  // Example number
        printf("Process 0: num1 = %d\n", num1);

        // Send num1 to process 1
        MPI_Send(&num1, 1, MPI_INT, 1, 0, MPI_COMM_WORLD);

        // Receive the sum from process 1
        MPI_Recv(&sum, 1, MPI_INT, 1, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        printf("Process 0: Received sum = %d\n", sum);

    } else if (rank == 1) {
        // Process 1 assigns the second number
        num2 = 20;  // Example number
        printf("Process 1: num2 = %d\n", num2);

        // Receive num1 from process 0
        MPI_Recv(&num1, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

        // Calculate the sum
        sum = num1 + num2;
        printf("Process 1: Calculated sum = %d\n", sum);

        // Send the sum back to process 0
        MPI_Send(&sum, 1, MPI_INT, 0, 0, MPI_COMM_WORLD);
    }

    // Finalize MPI environment
    MPI_Finalize();
    return 0;
}
