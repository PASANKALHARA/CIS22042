#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char** argv) {
    MPI_Init(&argc, &argv); 
    int world_size;
    MPI_Comm_size(MPI_COMM_WORLD, &world_size); 
    int world_rank;
    MPI_Comm_rank(MPI_COMM_WORLD, &world_rank); 
    if (world_size < 4) {
        if (world_rank == 0) { 
            printf("Error: The program requires at least 4 processes.\n");
        }
        MPI_Finalize();
        return 0;
    }
    const char* message = "MPI Programming in Distributed and Cloud Computing";
    printf("Process %d out of %d: %s\n", world_rank, world_size, message);
    MPI_Finalize(); 
    return 0;
}
