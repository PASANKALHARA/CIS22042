#include <mpi.h>
#include <stdio.h>

int main(int argc, char **argv) {
    int rank, size;
    int ping_pong_count = 0;   // Counter for the number of passes
    int max_ping_pong = 10;    // Maximum number of ping-pong exchanges
    int partner_rank;          // The rank of the other process

    // Initialize MPI environment
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    // Ensure there are exactly 2 processes
    if (size != 2) {
        if (rank == 0) {
            printf("This program requires exactly 2 processes.\n");
        }
        MPI_Finalize();
        return -1;
    }

    partner_rank = (rank == 0) ? 1 : 0;  // Determine the partner rank

    while (ping_pong_count < max_ping_pong) {
        if (rank == ping_pong_count % 2) {
            // This process "owns" the ball
            ping_pong_count++;
            MPI_Send(&ping_pong_count, 1, MPI_INT, partner_rank, 0, MPI_COMM_WORLD);
            printf("Process %d sent ping_pong_count = %d to process %d\n",
                   rank, ping_pong_count, partner_rank);
        } else {
            // Receive the ball from the partner
            MPI_Recv(&ping_pong_count, 1, MPI_INT, partner_rank, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            printf("Process %d received ping_pong_count = %d from process %d\n",
                   rank, ping_pong_count, partner_rank);
        }
    }

    // Finalize MPI environment
    MPI_Finalize();
    return 0;
}
