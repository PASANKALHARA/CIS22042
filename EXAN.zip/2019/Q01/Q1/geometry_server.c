#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include "geometry.h"

double *
rectangle_area_1_svc(struct rectangle *argp, struct svc_req *rqstp)
{
	static double  result;

	result = argp->length * argp->breadth;

	return &result;
}

double *
rectangle_perimeter_1_svc(struct rectangle *argp, struct svc_req *rqstp)
{
	static double  result;

	result = 2 * (argp->length + argp->breadth);

	return &result;
}

double *
triangle_area_1_svc(struct triangle *argp, struct svc_req *rqstp)
{
	static double  result;

	result = 0.5 * argp->base * argp->height;
	return &result;
}

double *
triangle_perimeter_1_svc(struct triangle *argp, struct svc_req *rqstp)
{
	static double  result;

	
    result = (1/2)*argp->base*argp->height;

	return &result;
}
