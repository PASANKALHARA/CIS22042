#include <stdio.h>
#include <stdlib.h>
#include "geometry.h"
#include <math.h>

void geometry_prog_1(char *host) {
    CLIENT *clnt;
    double *result_1;
    rectangle rectangle_area_1_arg;
    double *result_2;
    rectangle rectangle_perimeter_1_arg;
    double *result_3;
    triangle triangle_area_1_arg;
    double *result_4;
    triangle triangle_perimeter_1_arg;

#ifndef DEBUG
    clnt = clnt_create(host, GEOMETRY_PROG, GEOMETRY_VERS, "udp");
    if (clnt == NULL) {
        clnt_pcreateerror(host);
        exit(1);
    }
#endif 

    int choose;
    printf("Choose You Select\n");
    printf("1. Rectangle Area\n");
    printf("2. Rectangle Perimeter\n");
    printf("3. Triangle Area\n");
    printf("4. Triangle Perimeter\n");
    printf("Enter your choice: ");
    scanf("%d", &choose);

    switch (choose) {
        case 1:
            printf("Enter your length of rectangle: ");
            scanf("%lf", &(rectangle_area_1_arg.length));
            printf("Enter your breadth of rectangle: ");
            scanf("%lf", &(rectangle_area_1_arg.breadth));
            result_1 = rectangle_area_1(&rectangle_area_1_arg, clnt);
            if (result_1 == NULL) {
                clnt_perror(clnt, "Rectangle Area Calculation Failed");
            } else {
                printf("Your rectangle area: %.2f\n", *result_1);
            }
            break;

        case 2:
            printf("Enter your length of rectangle: ");
            scanf("%lf", &(rectangle_perimeter_1_arg.length));
            printf("Enter your breadth of rectangle: ");
            scanf("%lf", &(rectangle_perimeter_1_arg.breadth));
            result_2 = rectangle_perimeter_1(&rectangle_perimeter_1_arg, clnt);
            if (result_2 == NULL) {
                clnt_perror(clnt, "Rectangle Perimeter Calculation Failed");
            } else {
                printf("Your rectangle perimeter: %.2f\n", *result_2);
            }
            break;

        case 3:
            printf("Enter your base of triangle: ");
            scanf("%lf", &(triangle_area_1_arg.base));
            printf("Enter your height of triangle: ");
            scanf("%lf", &(triangle_area_1_arg.height));
            result_3 = triangle_area_1(&triangle_area_1_arg, clnt);
            if (result_3 == NULL) {
                clnt_perror(clnt, "Triangle Area Calculation Failed");
            } else {
                printf("Your triangle area: %.2f\n", *result_3);
            }
            break;

        case 4:
            printf("Enter your base of triangle: ");
            scanf("%lf", &(triangle_perimeter_1_arg.base));
            printf("Enter your height of triangle: ");
            scanf("%lf", &(triangle_perimeter_1_arg.height));
            result_4 = triangle_perimeter_1(&triangle_perimeter_1_arg, clnt);
            if (result_4 == NULL) {
                clnt_perror(clnt, "Triangle Perimeter Calculation Failed");
            } else {
                printf("Your triangle perimeter: %.2f\n", *result_4);
            }
            break;

        default:
            printf("ERROR: Selection is wrong\n");
    }

#ifndef DEBUG
    clnt_destroy(clnt);
#endif /* DEBUG */
}

int main(int argc, char *argv[]) {
    char *host;

    if (argc < 2) {
        printf("Usage: %s server_host\n", argv[0]);
        exit(1);
    }
    host = argv[1];
    geometry_prog_1(host);
    exit(0);
}
