#include "sumarray.h"

int *
sumarray_proc_1_svc(intarr *argp, struct svc_req *rqstp)
{
	static int  result;

	result = 0;
    for (int i = 0; i < argp->nums.nums_len; i++) {
        result += argp->nums.nums_val[i];
    }

	return &result;
}
