#include "sumarray.h"

void
sumarray_prog_1(char *host)
{
	CLIENT *clnt;
	int  *result_1;
	intarr  sumarray_proc_1_arg;
	int arrayLength;

#ifndef	DEBUG
	clnt = clnt_create (host, SUMARRAY_PROG, SUMARRAY_VERS, "udp");
	if (clnt == NULL) {
		clnt_pcreateerror (host);
		exit (1);
	}
#endif

	printf("Enter your Array length: ");
	scanf("%d", &arrayLength);

	sumarray_proc_1_arg.nums.nums_val = malloc(arrayLength * sizeof(int));
	sumarray_proc_1_arg.nums.nums_len = arrayLength;

	for (int i = 0; i < arrayLength; ++i) {
		printf("Enter your array element %d: ", i);
		scanf("%d", &sumarray_proc_1_arg.nums.nums_val[i]);
	}

	result_1 = sumarray_proc_1(&sumarray_proc_1_arg, clnt);
	if (result_1 == (int *) NULL) {
		clnt_perror (clnt, "call failed");
	}

	printf("Sum Of Array: %d\n", *result_1);

	free(sumarray_proc_1_arg.nums.nums_val);

#ifndef	DEBUG
	clnt_destroy (clnt);
#endif	 /* DEBUG */
}

int
main (int argc, char *argv[])
{
	char *host;

	if (argc < 2) {
		printf ("usage: %s server_host\n", argv[0]);
		exit (1);
	}
	host = argv[1];
	sumarray_prog_1 (host);
	exit (0);
}