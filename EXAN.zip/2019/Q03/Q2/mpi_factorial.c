#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>

// Function to calculate factorial
int factorial(int n) {
    if (n < 0) return -1; // Error for negative input
    if (n == 0 || n == 1) return 1;
    int result = 1;
    for (int i = 2; i <= n; i++) {
        result *= i;
    }
    return result;
}

int main(int argc, char* argv[]) {
    int rank, size;
    int input1 = 0, input2 = 0, result = 0;

    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    // Ensure exactly 4 processes
    if (size != 4) {
        if (rank == 0) {
            printf("This program requires exactly 4 processes.\n");
        }
        MPI_Finalize();
        return 1;
    }

    if (rank == 0) {
        // Process 0: Acquire user input and send it to Process 1
        printf("Process 0: Enter a number: ");
        fflush(stdout);
        if (scanf("%d", &input1) != 1) {
            printf("Process 0: Invalid input. Exiting.\n");
            MPI_Abort(MPI_COMM_WORLD, 1);
        }
        MPI_Send(&input1, 1, MPI_INT, 1, 0, MPI_COMM_WORLD);
        printf("Process 0: Sent %d to Process 1\n", input1);
    } else if (rank == 1) {
        // Process 1: Receive input from Process 0, add another number, and send sum to Process 2
        MPI_Recv(&input1, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        printf("Process 1: Received %d from Process 0\n", input1);
        printf("Process 1: Enter another number: ");
        fflush(stdout);
        if (scanf("%d", &input2) != 1) {
            printf("Process 1: Invalid input. Exiting.\n");
            MPI_Abort(MPI_COMM_WORLD, 1);
        }
        result = input1 + input2;
        MPI_Send(&result, 1, MPI_INT, 2, 0, MPI_COMM_WORLD);
        printf("Process 1: Sent %d to Process 2\n", result);
    } else if (rank == 2) {
        // Process 2: Receive sum from Process 1, subtract another number, and send difference to Process 3
        MPI_Recv(&input1, 1, MPI_INT, 1, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        printf("Process 2: Received %d from Process 1\n", input1);
        printf("Process 2: Enter another number: ");
        fflush(stdout);
        if (scanf("%d", &input2) != 1) {
            printf("Process 2: Invalid input. Exiting.\n");
            MPI_Abort(MPI_COMM_WORLD, 1);
        }
        result = input2 - input1;
        MPI_Send(&result, 1, MPI_INT, 3, 0, MPI_COMM_WORLD);
        printf("Process 2: Sent %d to Process 3\n", result);
    } else if (rank == 3) {
        // Process 3: Receive difference from Process 2, calculate factorial or display error
        MPI_Recv(&input1, 1, MPI_INT, 2, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        printf("Process 3: Received %d from Process 2\n", input1);
        if (input1 < 0) {
            printf("Process 3: Error - Cannot compute factorial of a negative number.\n");
        } else {
            result = factorial(input1);
            printf("Process 3: The factorial of %d is %d\n", input1, result);
        }
    }

    MPI_Finalize();
    return 0;
}
