#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>

int main(int argc, char** argv) {
    int rank, size;
    int page_words = 0;
    int total = 0;
    MPI_Status status;
    
    // Initialize MPI environment
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    
    // Check if we have exactly 3 processes
    if (size != 3) {
        if (rank == 0) {
            printf("This program requires exactly 3 processes.\n");
            printf("Please run with: mpirun -n 3 ./program\n");
        }
        MPI_Finalize();
        return 1;
    }

    // Process 0 handles all input sequentially
    if (rank == 0) {
        // Get input for process 0
        printf("Enter word count for page 1: ");
        fflush(stdout);
        scanf("%d", &page_words);
        total += page_words;

        // Get and send input for process 1
        int words_p1;
        printf("Enter word count for page 2: ");
        fflush(stdout);
        scanf("%d", &words_p1);
        MPI_Send(&words_p1, 1, MPI_INT, 1, 0, MPI_COMM_WORLD);
        total += words_p1;

        // Get and send input for process 2
        int words_p2;
        printf("Enter word count for page 3: ");
        fflush(stdout);
        scanf("%d", &words_p2);
        MPI_Send(&words_p2, 1, MPI_INT, 2, 0, MPI_COMM_WORLD);
        total += words_p2;

        // Print final total
        printf("Total words in the book: %d\n", total);
    }
    else {
        // Other processes just receive their values
        MPI_Recv(&page_words, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, &status);
    }
    
    MPI_Finalize();
    return 0;
}