import java.rmi.*;


public interface StringReverser extends Remote {
    // Method to reverse a string
    String reverseString(String input) throws RemoteException;
}
