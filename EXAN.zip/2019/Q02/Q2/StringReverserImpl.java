import java.rmi.*;
import java.rmi.server.*;

public class StringReverserImpl extends UnicastRemoteObject implements StringReverser {
    // Constructor
    protected StringReverserImpl() throws RemoteException {
        super();
    }

    // Method implementation to reverse a string
    @Override
    public String reverseString(String input) throws RemoteException {
        if (input == null) {
            return null;
        }
        // Convert the input string to a character array
        char[] chars = input.toCharArray();
        int length = chars.length;

        // Create a new character array for the reversed string
        char[] reversedChars = new char[length];

        // Copy characters in reverse order
        for (int i = 0; i < length; i++) {
            reversedChars[i] = chars[length - 1 - i];
        }

        // Convert the reversed character array back to a string
        return new String(reversedChars);

    }
}
