import java.rmi.registry.*;
import java.rmi.*;
public class RMIClient {
    public static void main(String[] args) {
        try {
           
            // Lookup the service
            StringReverser reverser = (StringReverser) Naming.lookup("StringReverserService");

            // Call the remote method
            String input = "Hello RMI";
            String reversed = reverser.reverseString(input);

            System.out.println("Original: " + input);
            System.out.println("Reversed: " + reversed);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
