import java.rmi.registry.*;
import java.rmi.*;

public class RMIServer {
    public static void main(String[] args) {
        try {
            // Create the implementation
            StringReverser reverser = new StringReverserImpl();

            // Bind the implementation to the registry
            Naming.rebind("StringReverserService", reverser);

            System.out.println("RMI Server is running...");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
