import java.rmi.Naming;

public class Client {
    public static void main(String[] args) {
        try {
            CylinderService service = (CylinderService) Naming.lookup("CylinderService");
            
            double radius = 5.0;
            double height = 10.0;

            double area = service.calculateArea(radius, height);
            double perimeter = service.calculatePerimeter(radius);
            double volume = service.calculateVolume(radius, height);

            System.out.println("Cylinder with Radius = " + radius + " and Height = " + height);
            System.out.println("Area: " + area);
            System.out.println("Perimeter: " + perimeter);
            System.out.println("Volume: " + volume);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
