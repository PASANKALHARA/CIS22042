import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;

public class Server {
    public static void main(String[] args) {
        try {
            
            CylinderService service = new CylinderServiceImpl();
            Naming.rebind("CylinderService", service);
            System.out.println("Cylinder Service is running...");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
