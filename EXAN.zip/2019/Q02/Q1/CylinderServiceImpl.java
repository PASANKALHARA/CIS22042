import java.rmi.server.UnicastRemoteObject;
import java.rmi.RemoteException;

public class CylinderServiceImpl extends UnicastRemoteObject implements CylinderService {

    protected CylinderServiceImpl() throws RemoteException {
        super();
    }

    @Override
    public double calculateArea(double radius, double height) throws RemoteException {
        return 2 * Math.PI * radius * (radius + height);
    }

    @Override
    public double calculatePerimeter(double radius) throws RemoteException {
        return 2 * Math.PI * radius;
    }

    @Override
    public double calculateVolume(double radius, double height) throws RemoteException {
        return Math.PI * Math.pow(radius, 2) * height;
    }
}
