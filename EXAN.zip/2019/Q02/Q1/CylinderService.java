import java.rmi.Remote;
import java.rmi.RemoteException;

public interface CylinderService extends Remote {
    double calculateArea(double radius, double height) throws RemoteException;
    double calculatePerimeter(double radius) throws RemoteException;
    double calculateVolume(double radius, double height) throws RemoteException;
}
